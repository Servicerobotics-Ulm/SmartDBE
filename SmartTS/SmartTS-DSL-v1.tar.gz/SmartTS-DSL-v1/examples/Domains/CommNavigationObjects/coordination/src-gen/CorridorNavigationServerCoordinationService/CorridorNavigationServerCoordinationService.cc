#include "CorridorNavigationServerCoordinationService.hh"

CorridorNavigationServerCoordinationService::CorridorNavigationServerCoordinationService (){
}
CorridorNavigationServerCoordinationService::~CorridorNavigationServerCoordinationService (){
	
}

