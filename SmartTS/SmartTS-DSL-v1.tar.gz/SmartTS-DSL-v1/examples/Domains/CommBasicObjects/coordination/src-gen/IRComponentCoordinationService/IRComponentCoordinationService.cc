#include "IRComponentCoordinationService.hh"

IRComponentCoordinationService::IRComponentCoordinationService (){
}
IRComponentCoordinationService::~IRComponentCoordinationService (){
	
}

