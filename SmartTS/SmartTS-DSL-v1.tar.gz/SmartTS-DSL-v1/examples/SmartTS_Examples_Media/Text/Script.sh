pdftoppm $1.pdf $1 -png
